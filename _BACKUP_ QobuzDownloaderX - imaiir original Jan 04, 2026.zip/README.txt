This is a backup of ImAiiR's QobuzDownloaderX as of Jan 04, 2026

Before merging pull-requests.

Just in case.